﻿using MyAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyAPI.Controllers
{
    public class MyInfoController : ApiController
    {

        public void Post([FromBody]MyInfo value)
        {
            //GOLILGRSPurchaseDetailsResps GGRSPDR = new GOLILGRSPurchaseDetailsResps();

            ManageDatabase MD = new ManageDatabase();

            //GGRSPDR = 
                MD.Myinfo(value);


            //return GGRSPDR;
        }
    }























}
}
