﻿using MyAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyAPI.Controllers
{
    public class MyFavPlaceController : ApiController
    {
        public void Post([FromBody]MyFavPlace value)
        {
            ManageDatabase MD = new ManageDatabase();
            MD.MyFavPlace(value);
        }
    }
}
