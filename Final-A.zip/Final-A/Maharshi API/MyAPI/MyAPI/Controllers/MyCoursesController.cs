﻿using MyAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyAPI.Controllers
{
    public class MyCoursesController : ApiController
    {
        public void Post([FromBody]MyCourses value)
        {
            ManageDatabase MD = new ManageDatabase();
            MD.MyCourses(value);
        }
    }
}
