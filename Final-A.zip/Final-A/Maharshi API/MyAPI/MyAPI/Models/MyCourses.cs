﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyAPI.Models
{
    public class MyCourses
    {
        public string Math { get; set; }
        public string IT { get; set; }
        public string English { get; set; }
        public string Optional { get; set; }
        public string Language { get; set; }
    }
}




//Request Json Format In Body
//  {
//      "Math":"",
//      "IT":"",
//      "English":"",
//      "Optional":"",
//      "Language":""
//  }