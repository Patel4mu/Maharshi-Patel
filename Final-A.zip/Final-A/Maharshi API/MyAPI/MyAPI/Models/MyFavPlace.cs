﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyAPI.Models
{
    public class MyFavPlace
    {
        public string CountryName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string District { get; set; }
        public string zipcode { get; set; }
    }
}







//Request Json Format In Body
//  {
//      "CountryName":"",
//      "City":"",
//      "State":"",
//      "District":"",
//      "zipcode":""
//  }