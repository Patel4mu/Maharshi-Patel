﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyAPI.Models
{
    public class MyInfo
    {
        public string Name { get; set; }
        public string DOB { get; set; }
        public string CollegeProgram { get; set; }
        public string Year { get; set; }
        public string Major { get; set; }
    }
}



//Request Json Format In Body
//  {
//      "Name":"",
//      "DOB":"",
//      "CollegeProgram":"",
//      "Year":"",
//      "Major":""
//  }
