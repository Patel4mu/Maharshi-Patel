﻿

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MyAPI.Models
{
    public class ManageDatabase
    {
        //Connection Sting
        string connetionString = "";

        //--------------------------My Info-------------------------------------------------------
        public void Myinfo(MyInfo value)
        {
            SqlConnection CON1 = new SqlConnection(connetionString);

            string Name, DOB, CollegeProgram, Year, Major;

            Name = value.Name.ToString();
            DOB = value.DOB.ToString();
            CollegeProgram = value.CollegeProgram.ToString();
            Year = value.Year.ToString();
            Major = value.Major.ToString();

            //Select Query
            string Select = @"Select * from tablename where  name='" + Name + "'  and DOB='" + DOB + "' ";

            //Delete Query
            string Delete = @" delete tablename where name='" + Name + "'  and DOB='" + DOB + "' ";

            //Insert Query
            string InsertQuery = @"Insert into tablename ([Name] ,[DOB] ,[CollegeProgram] ,[Year] ,[Major] )
                                     VALUES( '" + Name + "','" + DOB + "','" + CollegeProgram + "','" + Year + "','" + Major + "')";

            string UpdateQuery = @"Update tablename set DateInsert='GETDATE()'  Where name='" + Name + "'  and DOB='" + DOB + "' ";

            try
            {
                //Select
                CON1.Open();
                SqlDataAdapter SA = new SqlDataAdapter(Select, CON1);
                DataTable dt = new DataTable();
                SA.Fill(dt);
                CON1.Close();


                if (dt.Rows.Count == 0)
                {

                }
                else
                {
                    //Delete 
                    CON1.Open();
                    SqlCommand commDEL1 = new SqlCommand(Delete, CON1);
                    commDEL1.ExecuteNonQuery();
                    CON1.Close();

                    //Insert
                    CON1.Open();
                    SqlCommand comm1 = new SqlCommand(InsertQuery, CON1);
                    comm1.ExecuteNonQuery();
                    CON1.Close();


                    //Update
                    CON1.Open();
                    SqlCommand commUpdate = new SqlCommand(UpdateQuery, CON1);
                    commUpdate.ExecuteNonQuery();
                    CON1.Close();


                }





            }
            catch (Exception)
            {

                throw;
            }


        }

        //-------------------------------------My Fav Place------------------------------------------------
        public void MyFavPlace(MyFavPlace value)
        {
            SqlConnection CON1 = new SqlConnection(connetionString);

            string CountryName, City, State, District, zipcode;

            CountryName = value.CountryName.ToString();
            City = value.City.ToString();
            State = value.State.ToString();
            District = value.District.ToString();
            zipcode = value.zipcode.ToString();

            //Select Query
            string Select = @"Select * from tablename where  CountryName='" + CountryName + "'  and City='" + City + "' ";

            //Delete Query
            string Delete = @" delete tablename where CountryName='" + CountryName + "'  and City='" + City + "' ";

            //Insert Query
            string InsertQuery = @"Insert into tablename ([CountryName] ,[City] ,[State] ,[District] ,[zipcode] )
                                     VALUES( '" + CountryName + "','" + City + "','" + State + "','" + District + "','" + zipcode + "')";

            string UpdateQuery = @"Update tablename set DateInsert='GETDATE()'  Where CountryName='" + CountryName + "'  and City='" + City + "' ";

            try
            {
                //Select
                CON1.Open();
                SqlDataAdapter SA = new SqlDataAdapter(Select, CON1);
                DataTable dt = new DataTable();
                SA.Fill(dt);
                CON1.Close();


                if (dt.Rows.Count == 0)
                {

                }
                else
                {
                    //Delete 
                    CON1.Open();
                    SqlCommand commDEL1 = new SqlCommand(Delete, CON1);
                    commDEL1.ExecuteNonQuery();
                    CON1.Close();

                    //Insert
                    CON1.Open();
                    SqlCommand comm1 = new SqlCommand(InsertQuery, CON1);
                    comm1.ExecuteNonQuery();
                    CON1.Close();


                    //Update
                    CON1.Open();
                    SqlCommand commUpdate = new SqlCommand(UpdateQuery, CON1);
                    commUpdate.ExecuteNonQuery();
                    CON1.Close();


                }





            }
            catch (Exception)
            {

                throw;
            }


        }

        //-------------------------------------My Investement------------------------------------------------

        public void MyInvestement(MyInvestement value)
        {
            SqlConnection CON1 = new SqlConnection(connetionString);

            string Stocks, CryptoCurrency, Bank, Share, Property;

            Stocks = value.Stocks.ToString();
            CryptoCurrency = value.CryptoCurrency.ToString();
            Bank = value.Bank.ToString();
            Share = value.Share.ToString();
            Property = value.Property.ToString();

            //Select Query
            string Select = @"Select * from tablename where  Stocks='" + Stocks + "'  and CryptoCurrency='" + CryptoCurrency + "' ";

            //Delete Query
            string Delete = @" delete tablename where Stocks='" + Stocks + "'  and CryptoCurrency='" + CryptoCurrency + "' ";

            //Insert Query
            string InsertQuery = @"Insert into tablename ([Stocks] ,[CryptoCurrency] ,[Bank] ,[Share] ,[Property] )
                                     VALUES( '" + Stocks + "','" + CryptoCurrency + "','" + Bank + "','" + Share + "','" + Property + "')";

            string UpdateQuery = @"Update tablename set DateInsert='GETDATE()'  Where Stocks='" + Stocks + "'  and CryptoCurrency='" + CryptoCurrency + "' ";

            try
            {
                //Select
                CON1.Open();
                SqlDataAdapter SA = new SqlDataAdapter(Select, CON1);
                DataTable dt = new DataTable();
                SA.Fill(dt);
                CON1.Close();


                if (dt.Rows.Count == 0)
                {

                }
                else
                {
                    //Delete 
                    CON1.Open();
                    SqlCommand commDEL1 = new SqlCommand(Delete, CON1);
                    commDEL1.ExecuteNonQuery();
                    CON1.Close();

                    //Insert
                    CON1.Open();
                    SqlCommand comm1 = new SqlCommand(InsertQuery, CON1);
                    comm1.ExecuteNonQuery();
                    CON1.Close();


                    //Update
                    CON1.Open();
                    SqlCommand commUpdate = new SqlCommand(UpdateQuery, CON1);
                    commUpdate.ExecuteNonQuery();
                    CON1.Close();


                }





            }
            catch (Exception)
            {

                throw;
            }


        }

        //-------------------------------------My Courses------------------------------------------------

        public void MyCourses(MyCourses value)
        {
            SqlConnection CON1 = new SqlConnection(connetionString);

            string Math, IT, English, Optional, Language;

            Math = value.Math.ToString();
            IT = value.IT.ToString();
            English = value.English.ToString();
            Optional = value.Optional.ToString();
            Language = value.Language.ToString();

            //Select Query
            string Select = @"Select * from tablename where  Math='" + Math + "'  and IT='" + IT + "' ";

            //Delete Query
            string Delete = @" delete tablename where Math='" + Math + "'  and IT='" + IT + "' ";

            //Insert Query
            string InsertQuery = @"Insert into tablename ([Math] ,[IT] ,[English] ,[Optional] ,[Language] )
                                     VALUES( '" + Math + "','" + IT + "','" + English + "','" + Optional + "','" + Language + "')";

            string UpdateQuery = @"Update tablename set DateInsert='GETDATE()'  Where Math='" + Math + "'  and IT='" + IT + "' ";

            try
            {
                //Select
                CON1.Open();
                SqlDataAdapter SA = new SqlDataAdapter(Select, CON1);
                DataTable dt = new DataTable();
                SA.Fill(dt);
                CON1.Close();


                if (dt.Rows.Count == 0)
                {

                }
                else
                {
                    //Delete 
                    CON1.Open();
                    SqlCommand commDEL1 = new SqlCommand(Delete, CON1);
                    commDEL1.ExecuteNonQuery();
                    CON1.Close();

                    //Insert
                    CON1.Open();
                    SqlCommand comm1 = new SqlCommand(InsertQuery, CON1);
                    comm1.ExecuteNonQuery();
                    CON1.Close();


                    //Update
                    CON1.Open();
                    SqlCommand commUpdate = new SqlCommand(UpdateQuery, CON1);
                    commUpdate.ExecuteNonQuery();
                    CON1.Close();


                }





            }
            catch (Exception)
            {

                throw;
            }


        }


        //----------------------------------The End-------------------------------------------------------------
    }
}