﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyAPI.Models
{
    public class MyInvestement
    {
        public string Stocks { get; set; }
        public string CryptoCurrency { get; set; }
        public string Bank { get; set; }
        public string Share { get; set; }
        public string Property { get; set; }
    }
}









//Request Json Format In Body
//  {
//      "Stocks":"",
//      "CryptoCurrency":"",
//      "Bank":"",
//      "Share":"",
//      "Property":""
//  }